import './App.css';
import Kareler from './components/Kareler';

function App() {
  return (
    <>
      <Kareler />
    </>
  );
}

export default App;
